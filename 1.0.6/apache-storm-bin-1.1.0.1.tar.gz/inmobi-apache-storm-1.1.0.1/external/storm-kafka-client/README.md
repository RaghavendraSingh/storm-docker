#Storm Apache Kafka integration using the kafka-client jar (This includes the new Apache Kafka consumer API)

Spouts and Bolts that write to and read from Kafka through the kafka-client library.

Please see [here](../../docs/storm-kafka-client.md) for details on how to use it.
